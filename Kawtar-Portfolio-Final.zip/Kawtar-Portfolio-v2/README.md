# Kawtar Naoui Kheir — Portfolio

A responsive personal portfolio built with HTML, CSS and Vanilla JavaScript, inspired by the visual direction of the referenced Bedimcode portfolio tutorial: dark editorial layout, vivid green accent, rounded cards, smooth scrolling, reveal animations and interactive project case studies.

## Included
- Home / About / Work / Skills / Journey / Contact
- E-Résultat, QuizMaster and Data Dashboard case studies
- Responsive mobile navigation
- Dark / light mode
- Scroll reveal animations
- Active section navigation
- Custom cursor on desktop
- Project modal / case-study interactions
- Contact form that opens the user's mail application

## Before publishing
1. Open `index.html`.
2. Your email is already set to `kawtarnaouikheir@gmail.com`.
3. The LinkedIn button currently opens a LinkedIn people search for `Kawtar Naoui Kheir`; replace it with your exact profile URL if you want direct-profile navigation.
4. Open `index.html` in a browser to test.

## Publish
This is a static website. You can publish the folder directly with Vercel, Netlify or GitHub Pages.

## Important project accuracy
E-Résultat is intentionally described as a frontend/prototype contribution from the CHU Hassan II observation internship. Flask, MySQL and backend/authentication are not presented as completed features.
